import javax.swing.*;
import java.awt.*;

public class MyWindowTable_old extends JFrame {
    JTable studentsTable;
    JTable studentsTableFee;
    JTable studentsTableHighestFee;
    JTable studentsTableEvenLastname;
    JTable studentsTablePrimeName;
    JTable projectsTable;
    JLabel students = new JLabel("All students");
    JLabel lessFee = new JLabel("Decreasing fees for students by 10%");
    JLabel highestFee = new JLabel("Deleted a student whose fee is the highest");
    JLabel evenLastname = new JLabel("Students whose lastname contains even number of letters");
    JLabel primeName = new JLabel("Students whose name contains prime number of letters");
    StudentDAO studentDAO = new StudentDAO();
    ProjectDAO projectDAO = new ProjectDAO();
    public MyWindowTable_old() {

        // Table for students
        add(students);
        Object[][] students = studentDAO.read();

        String[] studentColumnNames = {"Student ID", "Name", "Lastname",
                "BirthDay", "Fee"};

        studentsTable = new JTable(students, studentColumnNames);
        studentsTable.setBounds(30, 40, 100, 100);

        JScrollPane sps = new JScrollPane(studentsTable);
        add(sps);

        // Table for students with 10% less fee
        add(lessFee);
        studentDAO.addStudentsFromDb();
        studentDAO.updateFee();
        Object[][] studentsUpdFee = studentDAO.read();

        String[] studentColumnNamesF = {"Student ID", "Name", "Lastname",
                "BirthDay", "Fee"};

        studentsTableFee = new JTable(studentsUpdFee, studentColumnNamesF);
        studentsTableFee.setBounds(30, 40, 100, 100);

        JScrollPane spsf = new JScrollPane(studentsTableFee);
        add(spsf);

        // Table for students without student with the highest fee
        add(highestFee);
        studentDAO.addStudentsFromDb();
        studentDAO.deleteStudentWithHighestFee();
        Object[][] studentsHighestFee = studentDAO.read();

        String[] studentColumnNamesHF = {"Student ID", "Name", "Lastname",
                "BirthDay", "Fee"};

        studentsTableHighestFee = new JTable(studentsHighestFee, studentColumnNamesHF);
        studentsTableHighestFee.setBounds(30, 40, 100, 100);

        JScrollPane spshf = new JScrollPane(studentsTableHighestFee);
        add(spshf);

        // Table for students without student with even lastname

        add(evenLastname);
        Object[][] studentsEvenLastname = studentDAO.studentsWithEvenLastname();

        String[] studentColumnNamesEL = {"Student ID", "Name", "Lastname",
                "BirthDay", "Fee"};

        studentsTableEvenLastname = new JTable(studentsEvenLastname, studentColumnNamesEL);
        studentsTableEvenLastname.setBounds(30, 40, 100, 100);

        JScrollPane spsel = new JScrollPane(studentsTableEvenLastname);
        add(spsel);

        // Table for students without student with prime name

        add(primeName);
        Object[][] studentsPrimeName = studentDAO.studentsWithPrimeName();

        String[] studentColumnNamesPN = {"Student ID", "Name", "Lastname",
                "BirthDay", "Fee"};

        studentsTablePrimeName = new JTable(studentsPrimeName, studentColumnNamesPN);
        studentsTablePrimeName.setBounds(30, 40, 100, 100);

        JScrollPane spspn = new JScrollPane(studentsTablePrimeName);
        add(spspn);


        // Table for projects

        Object[][] projects = projectDAO.read();

        String[] projectColumnNames = {"Project ID", "Project Name", "Student ID"};

        projectsTable = new JTable(projects, projectColumnNames);
        projectsTable.setBounds(30, 40, 100, 100);

        JScrollPane spp = new JScrollPane(projectsTable);
        add(spp);

        setLayout(new FlowLayout());
        setSize(800,800);
        setVisible(true);
    }



}
