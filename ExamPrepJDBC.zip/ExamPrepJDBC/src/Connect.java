import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Connect {
    public Connection connectToDB() {
        try {
            return DriverManager.getConnection("jdbc:mysql://localhost:3306/exam", "root", "Diana2001");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}
